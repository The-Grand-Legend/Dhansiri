"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ShoppingCart, Globe } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";

export default function Navbar() {
  const { t, lang, setLang } = useLanguage();
  const { totalCount } = useCart();
  const [open, setOpen] = useState(false);

  const links = [
    { href: "/", label: t("home") },
    { href: "/menu", label: t("menu") },
    { href: "/gallery", label: t("gallery") },
    { href: "/booking", label: t("booking") },
    { href: "/contact", label: t("contact") },
  ];

  return (
    <nav className="fixed top-0 z-50 w-full border-b border-[#D4AF37]/20 bg-[#0B0C10]/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="heading-font text-xl font-bold gold-gradient md:text-2xl">
          ধানসিঁড়ি
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm font-medium text-[#C5C6C7] transition hover:text-[#D4AF37]">
              {l.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setLang(lang === "en" ? "bn" : "en")}
            className="flex items-center gap-1 rounded-full border border-[#D4AF37]/30 px-3 py-1.5 text-xs font-medium text-[#D4AF37] transition hover:bg-[#D4AF37]/10"
          >
            <Globe size={14} />
            {lang === "en" ? "EN" : "BN"}
          </button>
          <Link href="/cart" className="relative text-[#C5C6C7] transition hover:text-[#D4AF37]">
            <ShoppingCart size={22} />
            {totalCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-[#D4AF37] text-[10px] font-bold text-[#0B0C10]">
                {totalCount}
              </span>
            )}
          </Link>
          <button className="text-[#C5C6C7] md:hidden" onClick={() => setOpen(!open)}>
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-[#D4AF37]/20 bg-[#0B0C10]/95 md:hidden"
          >
            <div className="flex flex-col gap-4 px-6 py-5">
              {links.map((l) => (
                <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="text-[#C5C6C7] hover:text-[#D4AF37]">
                  {l.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
