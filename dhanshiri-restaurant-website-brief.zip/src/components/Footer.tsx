"use client";

import Link from "next/link";
import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, MapPin } from "lucide-react";

export default function Footer() {
  const { t } = useLanguage();
  return (
    <footer className="border-t border-[#D4AF37]/20 bg-[#0B0C10] py-12">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 md:grid-cols-3">
        <div>
          <h3 className="heading-font text-2xl font-bold gold-gradient">ধানসিঁড়ি</h3>
          <p className="mt-3 text-sm text-[#C5C6C7]">{t("tagline")}</p>
        </div>
        <div>
          <h4 className="mb-3 font-semibold text-[#D4AF37]">{t("location")}</h4>
          <p className="flex items-start gap-2 text-sm text-[#C5C6C7]">
            <MapPin size={16} className="mt-0.5 shrink-0 text-[#D4AF37]" />
            2979+7F9 Haji Market, Mokamtola, Bogura, Bangladesh
          </p>
        </div>
        <div>
          <h4 className="mb-3 font-semibold text-[#D4AF37]">{t("contact")}</h4>
          <a href="tel:01912845151" className="flex items-center gap-2 text-sm text-[#C5C6C7] transition hover:text-[#D4AF37]">
            <Phone size={16} className="text-[#D4AF37]" />
            01912-845151
          </a>
          <div className="mt-4 flex gap-4 text-sm text-[#C5C6C7]">
            <Link href="/admin" className="hover:text-[#D4AF37]">{t("dashboard")}</Link>
            <Link href="/qr?table=1" className="hover:text-[#D4AF37]">{t("qrDineIn")}</Link>
          </div>
        </div>
      </div>
      <div className="mx-auto mt-10 max-w-7xl px-6 text-center text-xs text-[#C5C6C7]/60">
        © {new Date().getFullYear()} Dhanshiri Restaurant & Party Center. Built by Unique Web Pro.
      </div>
    </footer>
  );
}
