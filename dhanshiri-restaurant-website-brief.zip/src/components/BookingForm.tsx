"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Users, Clock, Utensils, PartyPopper } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const timeSlots = [
  "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM", "02:00 PM",
  "04:00 PM", "05:00 PM", "06:00 PM", "07:00 PM", "08:00 PM", "09:00 PM",
];

export default function BookingForm() {
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    bookingDate: "",
    timeSlot: timeSlots[5],
    guestCount: 2,
    bookingType: "dining" as "dining" | "party",
    notes: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) setSuccess(true);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-2xl border border-[#D4AF37]/30 bg-[#1F2833]/60 p-8 text-center"
      >
        <PartyPopper size={48} className="mx-auto text-[#D4AF37]" />
        <h3 className="mt-4 text-2xl font-bold text-[#F5F5F5]">Booking Request Sent!</h3>
        <p className="mt-2 text-[#C5C6C7]">We will call you at {form.phone} to confirm.</p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-[#C5C6C7]">{t("name")}</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-[#C5C6C7]">{t("phone")}</label>
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
          />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-[#C5C6C7]">Email</label>
        <input
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
        />
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        <div>
          <label className="mb-1 flex items-center gap-2 text-sm text-[#C5C6C7]">
            <Calendar size={14} /> {t("date")}
          </label>
          <input
            required
            type="date"
            value={form.bookingDate}
            onChange={(e) => setForm({ ...form, bookingDate: e.target.value })}
            className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
          />
        </div>
        <div>
          <label className="mb-1 flex items-center gap-2 text-sm text-[#C5C6C7]">
            <Clock size={14} /> {t("time")}
          </label>
          <select
            value={form.timeSlot}
            onChange={(e) => setForm({ ...form, timeSlot: e.target.value })}
            className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
          >
            {timeSlots.map((slot) => (
              <option key={slot} value={slot}>{slot}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 flex items-center gap-2 text-sm text-[#C5C6C7]">
            <Users size={14} /> {t("guests")}
          </label>
          <input
            required
            type="number"
            min={1}
            max={300}
            value={form.guestCount}
            onChange={(e) => setForm({ ...form, guestCount: parseInt(e.target.value) })}
            className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
          />
        </div>
      </div>

      <div>
        <label className="mb-2 flex items-center gap-2 text-sm text-[#C5C6C7]">
          <Utensils size={14} /> {t("type")}
        </label>
        <div className="flex gap-4">
          {(["dining", "party"] as const).map((type) => (
            <label key={type} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2 ${form.bookingType === type ? "border-[#D4AF37] bg-[#D4AF37]/10" : "border-[#D4AF37]/20 bg-[#0B0C10]/40"}`}>
              <input
                type="radio"
                name="bookingType"
                value={type}
                checked={form.bookingType === type}
                onChange={() => setForm({ ...form, bookingType: type })}
                className="accent-[#D4AF37]"
              />
              <span className="text-sm text-[#F5F5F5]">{t(type)}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-[#C5C6C7]">{t("notes")}</label>
        <textarea
          rows={3}
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-xl gold-btn py-3 font-bold disabled:opacity-60"
      >
        {loading ? "..." : t("submitBooking")}
      </button>
    </form>
  );
}
