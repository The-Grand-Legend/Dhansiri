"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import dynamic from "next/dynamic";

const GoldenCardScene = dynamic(() => import("./GoldenCardScene"), { ssr: false });

export default function Intro3D() {
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowIntro(false), 4200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {showIntro && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-[#0B0C10]"
        >
          <div className="relative h-full w-full">
            <GoldenCardScene />
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.8, duration: 1 }}
              className="pointer-events-none absolute inset-x-0 bottom-24 flex flex-col items-center text-center"
            >
              <h2 className="heading-font text-3xl font-bold gold-gradient md:text-5xl">
                ধানসিঁড়ি রেস্টুরেন্ট এন্ড পার্টি সেন্টার
              </h2>
              <p className="mt-2 text-sm tracking-widest text-[#C5C6C7] md:text-base">
                PREMIUM DINING & EVENTS
              </p>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
