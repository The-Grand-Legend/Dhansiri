"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export default function ReviewForm() {
  const { t } = useLanguage();
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, rating, comment }),
      });
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="rounded-2xl border border-[#D4AF37]/30 bg-[#1F2833]/60 p-6 text-center"
      >
        <h3 className="text-xl font-bold text-[#D4AF37]">Thank you!</h3>
        <p className="mt-2 text-[#C5C6C7]">Your review helps us serve you better.</p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h3 className="text-lg font-semibold text-[#F5F5F5]">{t("reviewPrompt")}</h3>
      <div>
        <label className="mb-1 block text-sm text-[#C5C6C7]">{t("name")}</label>
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-[#C5C6C7]">{t("rating")}</label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onMouseEnter={() => setHover(n)}
              onMouseLeave={() => setHover(0)}
              onClick={() => setRating(n)}
              className="text-[#D4AF37]"
            >
              <Star size={24} fill={n <= (hover || rating) ? "currentColor" : "none"} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="mb-1 block text-sm text-[#C5C6C7]">{t("comment")}</label>
        <textarea
          required
          rows={3}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
        />
      </div>
      <button type="submit" disabled={loading} className="w-full rounded-xl gold-btn py-2.5 font-bold disabled:opacity-60">
        {loading ? "..." : t("submitReview")}
      </button>
    </form>
  );
}
