"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { Star, Plus } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import { MenuItem } from "@/db/schema";

interface Props {
  item: MenuItem;
}

export default function MenuCard({ item }: Props) {
  const { t, lang } = useLanguage();
  const { addItem } = useCart();

  const handleAdd = () => {
    addItem({
      id: item.id,
      nameEn: item.nameEn,
      nameBn: item.nameBn,
      price: item.price,
      image: item.image,
    });
  };

  return (
    <motion.div
      whileHover={{ rotateX: 4, rotateY: -4, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 200, damping: 18 }}
      style={{ transformStyle: "preserve-3d" }}
      className="card-glass group relative overflow-hidden rounded-2xl"
    >
      {item.isBestseller && (
        <div className="absolute left-0 top-0 z-10 flex items-center gap-1 rounded-br-xl bg-[#D4AF37] px-3 py-1 text-xs font-bold text-[#0B0C10]">
          <Star size={12} fill="currentColor" /> {t("bestsellers")}
        </div>
      )}
      <div className="relative h-44 w-full overflow-hidden">
        {item.image ? (
          <Image
            src={item.image}
            alt={item.nameEn}
            fill
            className="object-cover transition duration-500 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-[#1F2833]">
            <span className="text-4xl">🍽️</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-transparent to-transparent" />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-[#F5F5F5]">{lang === "bn" ? item.nameBn : item.nameEn}</h3>
        {item.description && <p className="mt-1 line-clamp-2 text-xs text-[#C5C6C7]">{item.description}</p>}
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xl font-bold text-[#D4AF37]">৳{item.price}</span>
          <button
            onClick={handleAdd}
            className="flex items-center gap-1 rounded-full bg-[#0056D2] px-3 py-1.5 text-sm font-semibold text-white transition hover:bg-[#0044aa]"
          >
            <Plus size={16} /> {t("addToCart")}
          </button>
        </div>
      </div>
    </motion.div>
  );
}
