"use client";

import { useRef, useEffect, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

function Card() {
  const meshRef = useRef<THREE.Mesh>(null);
  const [scale, setScale] = useState(0.2);

  useEffect(() => {
    const t = setTimeout(() => setScale(2.2), 300);
    return () => clearTimeout(t);
  }, []);

  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.y = state.clock.elapsedTime * 0.6;
    meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.4) * 0.1;
    const targetScale = THREE.MathUtils.lerp(meshRef.current.scale.x, scale, 0.04);
    meshRef.current.scale.set(targetScale, targetScale, targetScale);
  });

  return (
    <mesh ref={meshRef}>
      <boxGeometry args={[2.4, 1.4, 0.08]} />
      <meshStandardMaterial
        color="#D4AF37"
        metalness={1}
        roughness={0.18}
        envMapIntensity={1.2}
      />
    </mesh>
  );
}

export default function GoldenCardScene() {
  return (
    <Canvas camera={{ position: [0, 0, 5], fov: 45 }} className="h-full w-full">
      <ambientLight intensity={0.6} />
      <pointLight position={[5, 5, 5]} intensity={2} color="#F3D77B" />
      <pointLight position={[-5, -5, 3]} intensity={1.5} color="#0056D2" />
      <pointLight position={[0, 4, 2]} intensity={1.2} color="#FFFFFF" />
      <Card />
    </Canvas>
  );
}
