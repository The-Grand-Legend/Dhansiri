import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { CartProvider } from "@/contexts/CartContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Toaster } from "sonner";

export const metadata: Metadata = {
  title: "Dhanshiri Restaurant & Party Center | Mokamtola, Bogura",
  description:
    "Premium fast food, Chinese cuisine, juice, coffee and party center bookings in Mokamtola, Bogura. Order online or book a table now.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-[#0B0C10] text-[#F5F5F5] antialiased">
        <LanguageProvider>
          <CartProvider>
            <Navbar />
            <main className="min-h-screen pt-20">{children}</main>
            <Footer />
            <Toaster position="top-center" richColors />
          </CartProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
