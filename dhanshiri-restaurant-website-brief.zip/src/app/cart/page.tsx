"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/contexts/CartContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";

const DELIVERY_FEE = 0;

export default function CartPage() {
  const { items, subtotal, totalCount, updateQuantity, removeItem } = useCart();
  const { t, lang } = useLanguage();
  const total = subtotal + DELIVERY_FEE;

  if (totalCount === 0) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
        <ShoppingBag size={64} className="text-[#D4AF37]/40" />
        <h2 className="mt-6 text-2xl font-bold text-[#F5F5F5]">{t("emptyCart")}</h2>
        <Link href="/menu" className="mt-4 rounded-full gold-btn px-8 py-3 font-bold">
          {t("viewMenu")}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <h1 className="text-3xl font-bold gold-gradient md:text-4xl">{t("cart")}</h1>
      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {items.map((item) => (
            <div key={item.id} className="flex gap-4 rounded-2xl border border-[#D4AF37]/10 bg-[#1F2833]/40 p-4">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl">
                {item.image ? (
                  <Image src={item.image} alt={item.nameEn} fill className="object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-[#1F2833]">🍽️</div>
                )}
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <h3 className="font-semibold text-[#F5F5F5]">{lang === "bn" ? item.nameBn : item.nameEn}</h3>
                  <p className="text-[#D4AF37]">৳{item.price}</p>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="rounded-lg bg-[#0B0C10] p-1 text-[#D4AF37]">
                    <Minus size={16} />
                  </button>
                  <span className="w-4 text-center font-semibold">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="rounded-lg bg-[#0B0C10] p-1 text-[#D4AF37]">
                    <Plus size={16} />
                  </button>
                  <button onClick={() => removeItem(item.id)} className="ml-auto text-red-400 transition hover:text-red-300">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="h-fit rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/60 p-6">
          <h2 className="text-xl font-bold text-[#F5F5F5]">{t("checkout")}</h2>
          <div className="mt-4 space-y-2 text-sm text-[#C5C6C7]">
            <div className="flex justify-between"><span>{t("subtotal")}</span><span>৳{subtotal}</span></div>
            <div className="flex justify-between"><span>{t("deliveryFee")}</span><span>৳{DELIVERY_FEE}</span></div>
            <div className="border-t border-[#D4AF37]/20 pt-2 flex justify-between text-lg font-bold text-[#F5F5F5]">
              <span>{t("total")}</span><span>৳{total}</span>
            </div>
          </div>
          <Link href="/checkout" className="mt-6 block w-full rounded-xl gold-btn py-3 text-center font-bold">
            {t("checkout")}
          </Link>
        </div>
      </div>
    </div>
  );
}
