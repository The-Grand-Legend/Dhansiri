"use client";

import { useState } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";

export default function PaymentContent() {
  const params = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const method = params.method as string;
  const orderId = parseInt(searchParams.get("orderId") || "0");
  const [status, setStatus] = useState<"idle" | "processing" | "success" | "failed">("idle");

  const simulate = async (outcome: "paid" | "failed") => {
    setStatus("processing");
    await new Promise((r) => setTimeout(r, 1500));
    try {
      const res = await fetch("/api/payment/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId, status: outcome }),
      });
      if (!res.ok) throw new Error("Payment update failed");
      setStatus(outcome === "paid" ? "success" : "failed");
      if (outcome === "paid") {
        toast.success("Payment successful!");
        setTimeout(() => router.push(`/track/${orderId}`), 1200);
      } else {
        toast.error("Payment failed.");
      }
    } catch (err: any) {
      toast.error(err.message);
      setStatus("failed");
    }
  };

  return (
    <div className="flex min-h-[70vh] items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md rounded-3xl border border-[#D4AF37]/30 bg-[#1F2833]/80 p-8 text-center"
      >
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-[#D4AF37]/10">
          <span className="text-3xl font-bold text-[#D4AF37]">{method === "bkash" ? "bK" : "Ng"}</span>
        </div>
        <h1 className="text-2xl font-bold text-[#F5F5F5]">{method === "bkash" ? "bKash" : "Nagad"} Checkout</h1>
        <p className="mt-2 text-sm text-[#C5C6C7]">Demo payment gateway for order #{orderId}</p>

        {status === "idle" && (
          <div className="mt-8 space-y-3">
            <button onClick={() => simulate("paid")} className="w-full rounded-xl gold-btn py-3 font-bold">
              Simulate Successful Payment
            </button>
            <button onClick={() => simulate("failed")} className="w-full rounded-xl border border-red-400 py-3 font-bold text-red-400 transition hover:bg-red-400/10">
              Simulate Failed Payment
            </button>
          </div>
        )}

        {status === "processing" && (
          <div className="mt-8 flex flex-col items-center text-[#C5C6C7]">
            <Loader2 className="animate-spin text-[#D4AF37]" size={40} />
            <p className="mt-3">Processing payment...</p>
          </div>
        )}

        {status === "success" && (
          <div className="mt-8 flex flex-col items-center text-green-400">
            <CheckCircle size={48} />
            <p className="mt-3 font-semibold">Payment Successful</p>
          </div>
        )}

        {status === "failed" && (
          <div className="mt-8 flex flex-col items-center text-red-400">
            <XCircle size={48} />
            <p className="mt-3 font-semibold">Payment Failed</p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
