"use client";

import { Suspense } from "react";
import PaymentContent from "./PaymentContent";

export default function PaymentPage() {
  return (
    <Suspense fallback={<div className="flex min-h-[70vh] items-center justify-center text-[#C5C6C7]">Loading...</div>}>
      <PaymentContent />
    </Suspense>
  );
}
