import { NextResponse } from "next/server";
import { db } from "@/db";
import { menuItems, categories } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db
    .select({
      item: menuItems,
      category: categories,
    })
    .from(menuItems)
    .innerJoin(categories, eq(menuItems.categoryId, categories.id))
    .where(eq(menuItems.isAvailable, true))
    .orderBy(categories.sortOrder, menuItems.id);

  return NextResponse.json({ items: items.map((i) => ({ ...i.item, category: i.category })) });
}
