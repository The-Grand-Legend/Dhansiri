import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { isAdminAuthenticated } from "@/lib/auth";

const updateSchema = z.object({
  status: z.enum(["pending", "confirmed", "cancelled"]).optional(),
});

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const bookingId = parseInt(id);
  if (isNaN(bookingId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const authed = await isAdminAuthenticated();
  if (!authed) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const data = updateSchema.parse(body);
    const updated = await db.update(bookings).set(data).where(eq(bookings.id, bookingId)).returning();
    return NextResponse.json({ booking: updated[0] });
  } catch {
    return NextResponse.json({ error: "Invalid data" }, { status: 400 });
  }
}
