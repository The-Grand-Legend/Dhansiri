import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { z } from "zod";
import { isAdminAuthenticated } from "@/lib/auth";
import { desc } from "drizzle-orm";

const bookingSchema = z.object({
  name: z.string().min(1),
  phone: z.string().min(1),
  email: z.string().optional(),
  bookingDate: z.string().min(1),
  timeSlot: z.string().min(1),
  guestCount: z.number().int().min(1),
  bookingType: z.enum(["dining", "party"]).default("dining"),
  notes: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = bookingSchema.parse(body);
    const [booking] = await db
      .insert(bookings)
      .values({
        name: data.name,
        phone: data.phone,
        email: data.email || null,
        bookingDate: data.bookingDate,
        timeSlot: data.timeSlot,
        guestCount: data.guestCount,
        bookingType: data.bookingType,
        notes: data.notes || null,
      })
      .returning();
    return NextResponse.json({ booking }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Invalid booking data" }, { status: 400 });
  }
}

export async function GET() {
  const authed = await isAdminAuthenticated();
  if (!authed) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const all = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  return NextResponse.json({ bookings: all });
}
