import { NextResponse } from "next/server";
import { db } from "@/db";
import { loyaltyPoints } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const phone = searchParams.get("phone");
  if (!phone) return NextResponse.json({ error: "Phone required" }, { status: 400 });
  const rows = await db.select().from(loyaltyPoints).where(eq(loyaltyPoints.phone, phone)).limit(1);
  return NextResponse.json({ points: rows[0] || { phone, points: 0, lifetimeSpend: 0 } });
}
