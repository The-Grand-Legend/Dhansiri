import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const all = await db.select().from(categories).orderBy(categories.sortOrder);
  return NextResponse.json({ categories: all });
}
