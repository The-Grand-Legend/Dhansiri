import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, bookings, reviews, menuItems } from "@/db/schema";
import { sql, eq, and, gte } from "drizzle-orm";
import { isAdminAuthenticated } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const authed = await isAdminAuthenticated();
  if (!authed) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [orderAgg] = await db
    .select({
      totalRevenue: sql<number>`COALESCE(SUM(${orders.total}), 0)`,
      totalOrders: sql<number>`COUNT(*)`,
    })
    .from(orders)
    .where(gte(orders.createdAt, today));

  const [pendingBookings] = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(bookings)
    .where(eq(bookings.status, "pending"));

  const [reviewAgg] = await db
    .select({ avg: sql<number>`COALESCE(AVG(${reviews.rating}), 0)` })
    .from(reviews);

  const totalItems = await db.select({ count: sql<number>`COUNT(*)` }).from(menuItems);

  return NextResponse.json({
    todayRevenue: orderAgg.totalRevenue || 0,
    todayOrders: Number(orderAgg.totalOrders) || 0,
    pendingBookings: Number(pendingBookings.count) || 0,
    averageRating: Number(reviewAgg.avg || 0).toFixed(1),
    menuItems: Number(totalItems[0].count) || 0,
  });
}
