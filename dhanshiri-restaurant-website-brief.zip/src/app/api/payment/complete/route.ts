import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  orderId: z.number(),
  status: z.enum(["paid", "failed"]).default("paid"),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = schema.parse(body);
    const updated = await db
      .update(orders)
      .set({ paymentStatus: data.status })
      .where(eq(orders.id, data.orderId))
      .returning();
    if (!updated.length) return NextResponse.json({ error: "Order not found" }, { status: 404 });
    return NextResponse.json({ order: updated[0] });
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}
