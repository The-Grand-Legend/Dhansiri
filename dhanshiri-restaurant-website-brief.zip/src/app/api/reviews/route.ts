import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { z } from "zod";
import { desc } from "drizzle-orm";

const reviewSchema = z.object({
  name: z.string().min(1),
  phone: z.string().optional(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().min(1),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = reviewSchema.parse(body);
    const [review] = await db
      .insert(reviews)
      .values({
        name: data.name,
        phone: data.phone || null,
        rating: data.rating,
        comment: data.comment,
      })
      .returning();
    return NextResponse.json({ review }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Invalid review data" }, { status: 400 });
  }
}

export async function GET() {
  const all = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(20);
  return NextResponse.json({ reviews: all });
}
