import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, menuItems, loyaltyPoints } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { isAdminAuthenticated } from "@/lib/auth";

const orderSchema = z.object({
  customerName: z.string().min(1),
  phone: z.string().min(1),
  address: z.string().optional(),
  orderType: z.enum(["delivery", "dine-in", "pickup"]).default("delivery"),
  paymentMethod: z.enum(["cod", "bkash", "nagad"]).default("cod"),
  notes: z.string().optional(),
  items: z.array(
    z.object({
      id: z.number(),
      name: z.string(),
      price: z.number(),
      quantity: z.number().int().min(1),
    })
  ).min(1),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = orderSchema.parse(body);

    const itemIds = data.items.map((i) => i.id);
    const dbItems = await db.select().from(menuItems).where(inArray(menuItems.id, itemIds));
    const priceMap = new Map(dbItems.map((i) => [i.id, i.price]));

    const total = data.items.reduce((sum, item) => {
      const realPrice = priceMap.get(item.id) ?? item.price;
      return sum + realPrice * item.quantity;
    }, 0);

    const [order] = await db.transaction(async (tx) => {
      const inserted = await tx
        .insert(orders)
        .values({
          customerName: data.customerName,
          phone: data.phone,
          address: data.address || null,
          orderType: data.orderType,
          paymentMethod: data.paymentMethod,
          paymentStatus: "pending",
          total,
          deliveryValidated: true,
          notes: data.notes || null,
        })
        .returning();

      const o = inserted[0];
      await tx.insert(orderItems).values(
        data.items.map((item) => ({
          orderId: o.id,
          menuItemId: item.id,
          name: item.name,
          price: priceMap.get(item.id) ?? item.price,
          quantity: item.quantity,
        }))
      );

      const pointsEarned = Math.floor(total / 10);
      const existing = await tx.select().from(loyaltyPoints).where(eq(loyaltyPoints.phone, data.phone)).limit(1);
      if (existing.length > 0) {
        await tx
          .update(loyaltyPoints)
          .set({
            points: existing[0].points + pointsEarned,
            lifetimeSpend: existing[0].lifetimeSpend + total,
            updatedAt: new Date(),
          })
          .where(eq(loyaltyPoints.id, existing[0].id));
      } else {
        await tx.insert(loyaltyPoints).values({
          phone: data.phone,
          points: pointsEarned,
          lifetimeSpend: total,
        });
      }

      return [o];
    });

    const paymentUrl =
      data.paymentMethod !== "cod"
        ? `/payment/${data.paymentMethod}?orderId=${order.id}`
        : null;

    return NextResponse.json({ order, paymentUrl }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Invalid order data" }, { status: 400 });
  }
}

export async function GET() {
  const authed = await isAdminAuthenticated();
  if (!authed) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const allOrders = await db.select().from(orders).orderBy(orders.createdAt);
  const items = await db.select().from(orderItems);
  return NextResponse.json({
    orders: allOrders.map((o) => ({
      ...o,
      items: items.filter((i) => i.orderId === o.id),
    })),
  });
}
