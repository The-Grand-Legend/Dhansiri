import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { isAdminAuthenticated } from "@/lib/auth";

const updateSchema = z.object({
  status: z.enum(["pending", "preparing", "out_for_delivery", "delivered", "cancelled"]).optional(),
  paymentStatus: z.enum(["pending", "paid", "failed"]).optional(),
});

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const orderId = parseInt(id);
  if (isNaN(orderId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const order = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  return NextResponse.json({ order: order[0], items });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const orderId = parseInt(id);
  if (isNaN(orderId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const authed = await isAdminAuthenticated();
  if (!authed) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const data = updateSchema.parse(body);
    const updated = await db
      .update(orders)
      .set(data)
      .where(eq(orders.id, orderId))
      .returning();
    return NextResponse.json({ order: updated[0] });
  } catch {
    return NextResponse.json({ error: "Invalid data" }, { status: 400 });
  }
}
