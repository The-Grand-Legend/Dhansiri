"use client";

import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, MapPin, Mail, Clock, Star } from "lucide-react";

export default function ContactPage() {
  const { t } = useLanguage();
  const [phone, setPhone] = useState("");
  const [points, setPoints] = useState<{ points: number; lifetimeSpend: number } | null>(null);

  const checkLoyalty = async () => {
    if (!phone) return;
    const res = await fetch(`/api/loyalty?phone=${encodeURIComponent(phone)}`);
    const data = await res.json();
    setPoints(data.points);
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold gold-gradient md:text-5xl">{t("contact")}</h1>
        <p className="mt-3 text-[#C5C6C7]">We would love to hear from you. Visit us or call for reservations.</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-6">
          <div className="flex items-start gap-4 rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5">
            <MapPin className="mt-1 text-[#D4AF37]" />
            <div>
              <h3 className="font-semibold text-[#F5F5F5]">{t("location")}</h3>
              <p className="text-[#C5C6C7]">2979+7F9 Haji Market, Mokamtola, Bogura, Bangladesh</p>
            </div>
          </div>
          <a href="tel:01912845151" className="flex items-start gap-4 rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5 transition hover:border-[#D4AF37]">
            <Phone className="mt-1 text-[#D4AF37]" />
            <div>
              <h3 className="font-semibold text-[#F5F5F5]">{t("callNow")}</h3>
              <p className="text-[#C5C6C7]">01912-845151</p>
            </div>
          </a>
          <div className="flex items-start gap-4 rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5">
            <Mail className="mt-1 text-[#D4AF37]" />
            <div>
              <h3 className="font-semibold text-[#F5F5F5]">Email</h3>
              <p className="text-[#C5C6C7]">hello@dhanshiri.com</p>
            </div>
          </div>
          <div className="flex items-start gap-4 rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5">
            <Clock className="mt-1 text-[#D4AF37]" />
            <div>
              <h3 className="font-semibold text-[#F5F5F5]">Opening Hours</h3>
              <p className="text-[#C5C6C7]">Daily: 10:00 AM – 10:00 PM</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="overflow-hidden rounded-3xl border border-[#D4AF37]/20">
            <iframe
              title="Dhanshiri Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620!2d89.35!3d24.85!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fc5c0c0c0c0c0c%3A0x0!2sHaji%20Market%2C%20Mokamtola!5e0!3m2!1sen!2sbd!4v1700000000000!5m2!1sen!2sbd"
              width="100%"
              height="320"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/60 p-6">
            <div className="flex items-center gap-2">
              <Star className="text-[#D4AF37]" size={20} />
              <h3 className="text-lg font-bold text-[#F5F5F5]">{t("loyalty")}</h3>
            </div>
            <p className="mt-2 text-sm text-[#C5C6C7]">Enter your phone number to check your Dhanshiri Points.</p>
            <div className="mt-4 flex gap-3">
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="flex-1 rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
              />
              <button onClick={checkLoyalty} className="rounded-xl gold-btn px-5 py-2.5 font-bold">Check</button>
            </div>
            {points && (
              <div className="mt-4 rounded-xl bg-[#0B0C10]/50 p-4 text-center">
                <p className="text-3xl font-bold text-[#D4AF37]">{points.points}</p>
                <p className="text-sm text-[#C5C6C7]">Points available</p>
                <p className="mt-1 text-xs text-[#C5C6C7]">Lifetime spend: ৳{points.lifetimeSpend}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
