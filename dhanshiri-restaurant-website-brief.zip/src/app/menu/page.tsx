"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import MenuCard from "@/components/MenuCard";
import { Category, MenuItem } from "@/db/schema";
import { ShoppingCart, ArrowRight } from "lucide-react";

export default function MenuPage() {
  const { t, lang } = useLanguage();
  const { subtotal, totalCount } = useCart();
  const [items, setItems] = useState<(MenuItem & { category: Category })[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [active, setActive] = useState<string>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetch("/api/categories").then((r) => r.json()), fetch("/api/menu").then((r) => r.json())]).then(
      ([catData, menuData]) => {
        setCategories(catData.categories);
        setItems(menuData.items);
        setLoading(false);
      }
    );
  }, []);

  const filtered = active === "all" ? items : items.filter((i) => i.category.slug === active);

  return (
    <div className="px-6 py-10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold gold-gradient md:text-5xl">{t("menu")}</h1>
          <p className="mt-3 text-[#C5C6C7]">Browse our digital menu, hold items and checkout when ready.</p>
        </div>

        {/* Category tabs */}
        <div className="mb-10 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => setActive("all")}
            className={`rounded-full px-5 py-2 text-sm font-medium transition ${active === "all" ? "gold-btn" : "border border-[#D4AF37]/30 text-[#C5C6C7] hover:border-[#D4AF37]"}`}
          >
            All
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.slug)}
              className={`rounded-full px-5 py-2 text-sm font-medium transition ${active === c.slug ? "gold-btn" : "border border-[#D4AF37]/30 text-[#C5C6C7] hover:border-[#D4AF37]"}`}
            >
              {lang === "bn" ? c.nameBn : c.nameEn}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-72 animate-pulse rounded-2xl bg-[#1F2833]/40" />
            ))}
          </div>
        ) : (
          <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filtered.map((item) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </motion.div>
        )}
      </div>

      {/* Floating cart summary */}
      {totalCount > 0 && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-6 left-6 right-6 z-40 mx-auto flex max-w-xl items-center justify-between rounded-2xl border border-[#D4AF37]/30 bg-[#1F2833]/90 px-5 py-3 backdrop-blur-md md:left-auto md:right-8"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#D4AF37] text-[#0B0C10]">
              <ShoppingCart size={18} />
            </div>
            <div>
              <p className="text-xs text-[#C5C6C7]">{totalCount} items held</p>
              <p className="font-bold text-[#F5F5F5]">৳{subtotal}</p>
            </div>
          </div>
          <Link href="/cart" className="flex items-center gap-1 rounded-full gold-btn px-5 py-2 text-sm font-bold">
            Checkout <ArrowRight size={16} />
          </Link>
        </motion.div>
      )}
    </div>
  );
}
