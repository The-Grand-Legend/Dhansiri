"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { LogOut, DollarSign, ShoppingBag, Calendar, Star, Utensils } from "lucide-react";

type Order = { id: number; customerName: string; phone: string; total: number; status: string; paymentStatus: string; paymentMethod: string; createdAt: string; items?: { name: string; quantity: number; price: number }[] };
type Booking = { id: number; name: string; phone: string; bookingDate: string; timeSlot: string; guestCount: number; bookingType: string; status: string };

export default function AdminPage() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [stats, setStats] = useState<any>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);

  const checkAuth = async () => {
    const res = await fetch("/api/admin/me");
    const data = await res.json();
    setAuthenticated(data.authenticated);
  };

  useEffect(() => {
    checkAuth();
  }, []);

  useEffect(() => {
    if (!authenticated) return;
    fetch("/api/dashboard").then((r) => r.json()).then(setStats);
    fetch("/api/orders").then((r) => r.json()).then((d) => setOrders(d.orders || []));
    fetch("/api/bookings").then((r) => r.json()).then((d) => setBookings(d.bookings || []));
  }, [authenticated]);

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password }) });
    if (res.ok) {
      setAuthenticated(true);
      toast.success("Welcome to the dashboard");
    } else {
      toast.error("Invalid password");
    }
  };

  const logout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    setAuthenticated(false);
  };

  const updateOrder = async (id: number, status: string) => {
    const res = await fetch(`/api/orders/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    if (res.ok) {
      toast.success("Order updated");
      setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
    }
  };

  const updateBooking = async (id: number, status: string) => {
    // We'll reuse a dedicated endpoint for bookings
    const res = await fetch(`/api/bookings/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    if (res.ok) {
      toast.success("Booking updated");
      setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)));
    }
  };

  if (authenticated === null) {
    return <div className="flex min-h-[60vh] items-center justify-center text-[#C5C6C7]">Loading...</div>;
  }

  if (!authenticated) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center px-6">
        <form onSubmit={login} className="w-full max-w-md rounded-3xl border border-[#D4AF37]/30 bg-[#1F2833]/80 p-8">
          <h1 className="text-2xl font-bold gold-gradient">Admin Login</h1>
          <p className="mt-2 text-sm text-[#C5C6C7]">Enter the dashboard password to continue.</p>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-6 w-full rounded-xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 px-4 py-3 text-[#F5F5F5] outline-none focus:border-[#D4AF37]"
            placeholder="Password"
          />
          <button type="submit" className="mt-4 w-full rounded-xl gold-btn py-3 font-bold">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="px-6 py-10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold gold-gradient">Admin Dashboard</h1>
          <button onClick={logout} className="flex items-center gap-2 rounded-xl border border-red-400 px-4 py-2 text-sm font-bold text-red-400 transition hover:bg-red-400/10">
            <LogOut size={16} /> Logout
          </button>
        </div>

        {stats && (
          <div className="mb-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { icon: DollarSign, label: "Today's Revenue", value: `৳${stats.todayRevenue}` },
              { icon: ShoppingBag, label: "Today's Orders", value: stats.todayOrders },
              { icon: Calendar, label: "Pending Bookings", value: stats.pendingBookings },
              { icon: Star, label: "Avg Rating", value: stats.averageRating },
              { icon: Utensils, label: "Menu Items", value: stats.menuItems },
            ].map((s, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/60 p-5">
                <s.icon size={24} className="text-[#D4AF37]" />
                <p className="mt-3 text-2xl font-bold text-[#F5F5F5]">{s.value}</p>
                <p className="text-xs text-[#C5C6C7]">{s.label}</p>
              </motion.div>
            ))}
          </div>
        )}

        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5">
            <h2 className="mb-4 text-xl font-bold text-[#F5F5F5]">Orders</h2>
            <div className="max-h-[500px] space-y-3 overflow-auto pr-2">
              {orders.map((o) => (
                <div key={o.id} className="rounded-xl bg-[#0B0C10]/50 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold text-[#F5F5F5]">#{o.id} — {o.customerName}</p>
                      <p className="text-xs text-[#C5C6C7]">{o.phone} • ৳{o.total} • {o.paymentMethod} • {o.paymentStatus}</p>
                    </div>
                    <select
                      value={o.status}
                      onChange={(e) => updateOrder(o.id, e.target.value)}
                      className="rounded-lg border border-[#D4AF37]/30 bg-[#0B0C10] px-2 py-1 text-xs text-[#F5F5F5]"
                    >
                      {["pending", "preparing", "out_for_delivery", "delivered", "cancelled"].map((s) => (
                        <option key={s} value={s}>{s.replace(/_/g, " ")}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-5">
            <h2 className="mb-4 text-xl font-bold text-[#F5F5F5]">Bookings</h2>
            <div className="max-h-[500px] space-y-3 overflow-auto pr-2">
              {bookings.map((b) => (
                <div key={b.id} className="rounded-xl bg-[#0B0C10]/50 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold text-[#F5F5F5]">#{b.id} — {b.name}</p>
                      <p className="text-xs text-[#C5C6C7]">{b.phone} • {b.bookingDate} {b.timeSlot} • {b.guestCount} guests • {b.bookingType}</p>
                    </div>
                    <select
                      value={b.status}
                      onChange={(e) => updateBooking(b.id, e.target.value)}
                      className="rounded-lg border border-[#D4AF37]/30 bg-[#0B0C10] px-2 py-1 text-xs text-[#F5F5F5]"
                    >
                      {["pending", "confirmed", "cancelled"].map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
