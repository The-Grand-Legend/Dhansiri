"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";

const images = [
  { src: "https://images.pexels.com/photos/17294773/pexels-photo-17294773.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", title: "Elegant Dining" },
  { src: "https://images.pexels.com/photos/17001777/pexels-photo-17001777.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", title: "Party Setup" },
  { src: "https://images.pexels.com/photos/15063328/pexels-photo-15063328.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", title: "Lobby Ambience" },
  { src: "https://images.pexels.com/photos/16935897/pexels-photo-16935897.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", title: "Celebration Hall" },
  { src: "https://images.pexels.com/photos/12129480/pexels-photo-12129480.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", title: "Signature Burger" },
  { src: "https://images.pexels.com/photos/18698263/pexels-photo-18698263.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", title: "Chinese Platter" },
];

export default function GalleryPage() {
  const { t } = useLanguage();
  return (
    <div className="px-6 py-10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 text-center">
          <h1 className="text-4xl font-bold gold-gradient md:text-5xl">{t("gallery")}</h1>
          <p className="mt-3 text-[#C5C6C7]">A glimpse of our lobby, party center and delicious moments.</p>
        </div>
        <div className="columns-1 gap-4 space-y-4 md:columns-2 lg:columns-3">
          {images.map((img, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative overflow-hidden rounded-2xl break-inside-avoid"
            >
              <Image src={img.src} alt={img.title} width={800} height={600} className="w-full object-cover transition duration-500 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10]/80 via-transparent to-transparent opacity-0 transition group-hover:opacity-100" />
              <p className="absolute bottom-4 left-4 translate-y-4 font-semibold text-white opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100">
                {img.title}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
