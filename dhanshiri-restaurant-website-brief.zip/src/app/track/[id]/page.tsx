"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle2, ChefHat, Truck, Package, XCircle } from "lucide-react";

const steps = [
  { key: "pending", label: "Order Received", icon: Package },
  { key: "preparing", label: "Preparing", icon: ChefHat },
  { key: "out_for_delivery", label: "Out for Delivery", icon: Truck },
  { key: "delivered", label: "Delivered", icon: CheckCircle2 },
];

export default function TrackPage() {
  const params = useParams();
  const id = parseInt(params.id as string);
  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/orders/${id}`)
      .then((r) => r.json())
      .then((data) => {
        setOrder(data.order);
        setItems(data.items || []);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div className="flex min-h-[50vh] items-center justify-center text-[#C5C6C7]">Loading...</div>;
  }

  if (!order) {
    return <div className="flex min-h-[50vh] items-center justify-center text-[#C5C6C7]">Order not found.</div>;
  }

  const activeIndex = order.status === "cancelled" ? -1 : steps.findIndex((s) => s.key === order.status);

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="text-3xl font-bold gold-gradient">Order #{order.id}</h1>
      <p className="mt-2 text-[#C5C6C7]">Status: <span className="font-semibold capitalize text-[#D4AF37]">{order.status.replace(/_/g, " ")}</span></p>

      {order.status === "cancelled" ? (
        <div className="mt-8 flex items-center gap-3 rounded-2xl border border-red-400/30 bg-red-400/10 p-5 text-red-400">
          <XCircle size={28} />
          <span className="font-semibold">This order has been cancelled.</span>
        </div>
      ) : (
        <div className="mt-8">
          <div className="relative flex justify-between">
            <div className="absolute left-0 top-1/2 h-1 w-full -translate-y-1/2 rounded bg-[#1F2833]">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(Math.max(activeIndex, 0) / (steps.length - 1)) * 100}%` }}
                className="h-full rounded bg-[#D4AF37]"
              />
            </div>
            {steps.map((step, idx) => {
              const Icon = step.icon;
              const isActive = idx <= activeIndex;
              return (
                <div key={step.key} className="relative z-10 flex flex-col items-center gap-2">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${isActive ? "border-[#D4AF37] bg-[#D4AF37] text-[#0B0C10]" : "border-[#1F2833] bg-[#0B0C10] text-[#C5C6C7]"}`}>
                    <Icon size={18} />
                  </div>
                  <span className={`text-xs ${isActive ? "text-[#D4AF37]" : "text-[#C5C6C7]"}`}>{step.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-10 rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/60 p-6">
        <h2 className="text-xl font-bold text-[#F5F5F5]">Items</h2>
        <div className="mt-4 space-y-2">
          {items.map((i: any) => (
            <div key={i.id} className="flex justify-between text-sm text-[#C5C6C7]">
              <span>{i.name} x{i.quantity}</span>
              <span>৳{i.price * i.quantity}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 border-t border-[#D4AF37]/20 pt-3 flex justify-between font-bold text-[#F5F5F5]">
          <span>Total</span>
          <span>৳{order.total}</span>
        </div>
      </div>
    </div>
  );
}
