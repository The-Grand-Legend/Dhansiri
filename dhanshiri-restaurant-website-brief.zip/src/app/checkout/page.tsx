"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/contexts/CartContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import { CreditCard, Truck, Wallet, Banknote } from "lucide-react";

export default function CheckoutPage() {
  const { t } = useLanguage();
  const { items, subtotal, clearCart } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    customerName: "",
    phone: "",
    address: "",
    orderType: "delivery" as "delivery" | "dine-in" | "pickup",
    paymentMethod: "cod" as "cod" | "bkash" | "nagad",
    notes: "",
  });

  const total = subtotal;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: items.map((i) => ({ id: i.id, name: i.nameEn, price: i.price, quantity: i.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Order failed");
      clearCart();
      toast.success("Order placed successfully!");
      if (data.paymentUrl) {
        router.push(data.paymentUrl);
      } else {
        router.push(`/track/${data.order.id}`);
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
        <h2 className="text-2xl font-bold text-[#F5F5F5]">{t("emptyCart")}</h2>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="text-3xl font-bold gold-gradient md:text-4xl">{t("checkout")}</h1>
      <form onSubmit={handleSubmit} className="mt-8 space-y-5">
        <div className="grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm text-[#C5C6C7]">{t("name")}</label>
            <input required value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#1F2833]/40 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-[#C5C6C7]">{t("phone")}</label>
            <input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#1F2833]/40 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]" />
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm text-[#C5C6C7]">{t("address")}</label>
          <textarea required={form.orderType === "delivery"} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#1F2833]/40 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]" />
        </div>

        <div>
          <label className="mb-2 block text-sm text-[#C5C6C7]">{t("type")}</label>
          <div className="flex flex-wrap gap-3">
            {(["delivery", "dine-in", "pickup"] as const).map((type) => (
              <label key={type} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2 ${form.orderType === type ? "border-[#D4AF37] bg-[#D4AF37]/10" : "border-[#D4AF37]/20 bg-[#0B0C10]/40"}`}>
                <input type="radio" name="orderType" value={type} checked={form.orderType === type} onChange={() => setForm({ ...form, orderType: type })} className="accent-[#D4AF37]" />
                <span className="text-sm capitalize text-[#F5F5F5]">{type.replace("-", " ")}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm text-[#C5C6C7]">{t("paymentMethod")}</label>
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              { key: "cod", icon: Banknote, label: t("cod") },
              { key: "bkash", icon: Wallet, label: t("bkash") },
              { key: "nagad", icon: CreditCard, label: t("nagad") },
            ].map(({ key, icon: Icon, label }) => (
              <label key={key} className={`flex cursor-pointer flex-col items-center gap-2 rounded-xl border p-4 transition ${form.paymentMethod === key ? "border-[#D4AF37] bg-[#D4AF37]/10" : "border-[#D4AF37]/20 bg-[#0B0C10]/40 hover:border-[#D4AF37]/50"}`}>
                <input type="radio" name="payment" value={key} checked={form.paymentMethod === key} onChange={() => setForm({ ...form, paymentMethod: key as any })} className="accent-[#D4AF37]" />
                <Icon size={24} className="text-[#D4AF37]" />
                <span className="text-sm font-medium text-[#F5F5F5]">{label}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm text-[#C5C6C7]">{t("notes")}</label>
          <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="w-full rounded-xl border border-[#D4AF37]/20 bg-[#1F2833]/40 px-4 py-2.5 text-[#F5F5F5] outline-none focus:border-[#D4AF37]" />
        </div>

        <div className="rounded-2xl border border-[#D4AF37]/20 bg-[#1F2833]/60 p-5">
          <div className="flex justify-between text-lg font-bold text-[#F5F5F5]">
            <span>{t("total")}</span>
            <span>৳{total}</span>
          </div>
          <p className="mt-1 text-xs text-[#C5C6C7]">Free delivery within Mokamtola</p>
        </div>

        <button type="submit" disabled={loading} className="w-full rounded-xl gold-btn py-3.5 font-bold disabled:opacity-60">
          {loading ? "Processing..." : t("placeOrder")}
        </button>
      </form>
    </div>
  );
}
