"use client";

import { Suspense } from "react";
import QRContent from "./QRContent";

export default function QRPage() {
  return (
    <Suspense fallback={<div className="flex min-h-[70vh] items-center justify-center text-[#C5C6C7]">Loading...</div>}>
      <QRContent />
    </Suspense>
  );
}
