"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useLanguage } from "@/contexts/LanguageContext";
import QRCode from "qrcode";
import { QrCode } from "lucide-react";

export default function QRContent() {
  const { t } = useLanguage();
  const searchParams = useSearchParams();
  const table = searchParams.get("table") || "1";
  const [dataUrl, setDataUrl] = useState<string>("");

  useEffect(() => {
    const origin = typeof window !== "undefined" ? window.location.origin : "";
    const url = `${origin}/menu?table=${table}`;
    QRCode.toDataURL(url, { width: 280, margin: 2, color: { dark: "#D4AF37", light: "#0B0C10" } })
      .then(setDataUrl)
      .catch(console.error);
  }, [table]);

  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-6 py-10 text-center">
      <QrCode size={48} className="text-[#D4AF37]" />
      <h1 className="mt-4 text-3xl font-bold gold-gradient md:text-4xl">{t("qrDineIn")}</h1>
      <p className="mt-3 max-w-md text-[#C5C6C7]">{t("scanToOrder")}</p>
      <div className="mt-8 rounded-3xl border-4 border-[#D4AF37] bg-white p-4">
        {dataUrl ? (
          <img src={dataUrl} alt="Table QR Code" className="h-64 w-64" />
        ) : (
          <div className="flex h-64 w-64 items-center justify-center bg-[#0B0C10]">
            <span className="text-[#C5C6C7]">Generating...</span>
          </div>
        )}
      </div>
      <p className="mt-6 text-lg font-semibold text-[#F5F5F5]">
        {t("tableNumber")}: {table}
      </p>
      <p className="mt-2 text-sm text-[#C5C6C7]">Scan to open the digital menu</p>
    </div>
  );
}
