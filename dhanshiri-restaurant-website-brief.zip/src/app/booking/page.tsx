"use client";

import { useLanguage } from "@/contexts/LanguageContext";
import BookingForm from "@/components/BookingForm";
import { CalendarDays } from "lucide-react";

export default function BookingPage() {
  const { t } = useLanguage();
  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <div className="mb-8 text-center">
        <CalendarDays size={48} className="mx-auto text-[#D4AF37]" />
        <h1 className="mt-4 text-3xl font-bold gold-gradient md:text-4xl">{t("reserveTable")}</h1>
        <p className="mt-3 text-[#C5C6C7]">Reserve a table or the party center for your next celebration.</p>
      </div>
      <div className="rounded-3xl border border-[#D4AF37]/20 bg-[#1F2833]/40 p-6 md:p-10">
        <BookingForm />
      </div>
    </div>
  );
}
