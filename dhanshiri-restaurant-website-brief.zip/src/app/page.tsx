import Link from "next/link";
import Image from "next/image";
import { db } from "@/db";
import { menuItems, categories, reviews } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import Intro3D from "@/components/Intro3D";
import MenuCard from "@/components/MenuCard";
import ReviewForm from "@/components/ReviewForm";
import { Phone, MapPin, Clock, ArrowRight, Star } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const bestsellers = await db
    .select({ item: menuItems, category: categories })
    .from(menuItems)
    .innerJoin(categories, eq(menuItems.categoryId, categories.id))
    .where(eq(menuItems.isBestseller, true))
    .limit(4);

  const recentReviews = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(4);

  const galleryImages = [
    "https://images.pexels.com/photos/17294773/pexels-photo-17294773.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    "https://images.pexels.com/photos/17001777/pexels-photo-17001777.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    "https://images.pexels.com/photos/15063328/pexels-photo-15063328.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    "https://images.pexels.com/photos/16935897/pexels-photo-16935897.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  ];

  return (
    <>
      <Intro3D />

      {/* Hero */}
      <section className="relative flex min-h-[90vh] items-center justify-center overflow-hidden px-6">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://images.pexels.com/photos/16935897/pexels-photo-16935897.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
            alt="Dhanshiri Interior"
            fill
            className="object-cover opacity-30"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0B0C10]/60 via-[#0B0C10]/80 to-[#0B0C10]" />
        </div>
        <div className="relative z-10 mx-auto max-w-4xl text-center">
          <p className="text-sm uppercase tracking-[0.3em] text-[#D4AF37]">Welcome to</p>
          <h1 className="mt-4 text-[clamp(2.5rem,7vw,5rem)] font-bold leading-[1.1] gold-gradient">
            ধানসিঁড়ি রেস্টুরেন্ট<br />এন্ড পার্টি সেন্টার
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-[#C5C6C7]">
            Premium fast food, Chinese delights & a stunning party venue in the heart of Mokamtola, Bogura.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Link href="/menu" className="rounded-full gold-btn px-8 py-3.5 font-bold">
              View Digital Menu
            </Link>
            <Link href="/booking" className="rounded-full border border-[#D4AF37] px-8 py-3.5 font-bold text-[#D4AF37] transition hover:bg-[#D4AF37]/10">
              Book a Table
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-[#C5C6C7]">
            <span className="flex items-center gap-2"><Clock size={16} className="text-[#D4AF37]" /> Saturdays, 4 PM</span>
            <span className="flex items-center gap-2"><Phone size={16} className="text-[#D4AF37]" /> 01912-845151</span>
          </div>
        </div>
      </section>

      {/* Bestsellers */}
      <section className="px-6 py-20">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <p className="text-sm uppercase tracking-widest text-[#D4AF37]">Crowd Favorites</p>
              <h2 className="mt-2 text-3xl font-bold text-[#F5F5F5] md:text-4xl">Best Sellers</h2>
            </div>
            <Link href="/menu" className="hidden items-center gap-1 text-[#D4AF37] hover:underline md:flex">
              Full Menu <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {bestsellers.map(({ item }) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section className="bg-[#1F2833]/30 px-6 py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-12 md:grid-cols-2">
          <div className="relative h-80 overflow-hidden rounded-3xl md:h-[28rem]">
            <Image
              src="https://images.pexels.com/photos/17294773/pexels-photo-17294773.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="About Dhanshiri"
              fill
              className="object-cover"
            />
          </div>
          <div>
            <p className="text-sm uppercase tracking-widest text-[#D4AF37]">Our Story</p>
            <h2 className="mt-2 text-3xl font-bold text-[#F5F5F5] md:text-4xl">About Dhanshiri</h2>
            <p className="mt-5 text-[#C5C6C7] leading-relaxed">
              Located at Haji Market, Mokamtola, Bogura, Dhanshiri Restaurant & Party Center is your destination for delicious fast food, authentic Chinese cuisine, refreshing juices and premium coffee. Our elegant party center is perfect for birthdays, meetings and family celebrations.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/gallery" className="rounded-full border border-[#D4AF37] px-6 py-2.5 text-[#D4AF37] transition hover:bg-[#D4AF37]/10">
                Explore Gallery
              </Link>
              <a href="tel:01912845151" className="flex items-center gap-2 rounded-full bg-[#0056D2] px-6 py-2.5 text-white transition hover:bg-[#0044aa]">
                <Phone size={16} /> Call Now
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery preview */}
      <section className="px-6 py-20">
        <div className="mx-auto max-w-7xl">
          <p className="text-sm uppercase tracking-widest text-[#D4AF37]">Ambience</p>
          <h2 className="mt-2 text-3xl font-bold text-[#F5F5F5] md:text-4xl">Lobby & Party Center</h2>
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {galleryImages.map((src, idx) => (
              <div key={idx} className="relative aspect-square overflow-hidden rounded-2xl">
                <Image src={src} alt={`Gallery ${idx + 1}`} fill className="object-cover transition hover:scale-105" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="bg-[#1F2833]/30 px-6 py-20">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-2">
          <div>
            <p className="text-sm uppercase tracking-widest text-[#D4AF37]">What guests say</p>
            <h2 className="mt-2 text-3xl font-bold text-[#F5F5F5] md:text-4xl">Reviews</h2>
            <div className="mt-8 space-y-4">
              {recentReviews.map((r) => (
                <div key={r.id} className="rounded-2xl border border-[#D4AF37]/10 bg-[#0B0C10]/50 p-5">
                  <div className="flex items-center gap-1 text-[#D4AF37]">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} size={14} fill={i < r.rating ? "currentColor" : "none"} />
                    ))}
                  </div>
                  <p className="mt-2 text-[#F5F5F5]">{r.comment}</p>
                  <p className="mt-2 text-xs text-[#C5C6C7]">— {r.name}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-[#D4AF37]/20 bg-[#0B0C10]/60 p-6 md:p-8">
            <ReviewForm />
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="px-6 py-20">
        <div className="mx-auto max-w-5xl rounded-3xl bg-gradient-to-r from-[#1F2833] to-[#0B0C10] p-8 text-center md:p-14">
          <h2 className="text-3xl font-bold text-[#F5F5F5] md:text-4xl">Visit Dhanshiri Today</h2>
          <p className="mx-auto mt-4 max-w-xl text-[#C5C6C7]">
            Experience the golden standard of dining and events in Mokamtola. We are open every day for dine-in, takeaway and party bookings.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a href="https://maps.google.com/?q=2979%2B7F9%20Haji%20Market%2C%20Mokamtola" target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full gold-btn px-6 py-3 font-bold">
              <MapPin size={18} /> Get Directions
            </a>
            <Link href="/booking" className="rounded-full border border-[#D4AF37] px-6 py-3 font-bold text-[#D4AF37] transition hover:bg-[#D4AF37]/10">
              Reserve Now
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
