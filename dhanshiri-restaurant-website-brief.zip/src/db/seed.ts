import "dotenv/config";
import { db } from "./index";
import { categories, menuItems } from "./schema";
import { eq } from "drizzle-orm";

const categoryData = [
  { slug: "fast-food", nameEn: "Fast Food", nameBn: "ফাস্ট ফুড", sortOrder: 1 },
  { slug: "chinese", nameEn: "Chinese", nameBn: "চাইনিজ", sortOrder: 2 },
  { slug: "juice", nameEn: "Juice & Drinks", nameBn: "জুস ও পানীয়", sortOrder: 3 },
  { slug: "coffee", nameEn: "Coffee", nameBn: "কফি", sortOrder: 4 },
  { slug: "set-menu", nameEn: "Set Menu", nameBn: "সেট মেনু", sortOrder: 5 },
];

const itemData = [
  {
    categorySlug: "fast-food",
    nameEn: "Chicken Petty Burger",
    nameBn: "চিকেন পেটি বার্গার",
    price: 130,
    image:
      "https://images.pexels.com/photos/12129480/pexels-photo-12129480.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: true,
    description: "Crispy chicken patty, fresh lettuce, signature sauce.",
  },
  {
    categorySlug: "fast-food",
    nameEn: "Double Beef Burger",
    nameBn: "ডবল বিফ বার্গার",
    price: 220,
    image:
      "https://images.pexels.com/photos/20722043/pexels-photo-20722043.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: false,
    description: "Juicy double beef patties with melted cheese.",
  },
  {
    categorySlug: "chinese",
    nameEn: "Chicken Chowmein",
    nameBn: "চিকেন চাউমিন",
    price: 180,
    image:
      "https://images.pexels.com/photos/18698263/pexels-photo-18698263.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: true,
    description: "Stir-fried noodles with tender chicken and vegetables.",
  },
  {
    categorySlug: "chinese",
    nameEn: "Fried Rice Special",
    nameBn: "ফ্রাইড রাইস স্পেশাল",
    price: 200,
    image:
      "https://images.pexels.com/photos/32612771/pexels-photo-32612771.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: false,
    description: "Aromatic fried rice with egg, chicken and spices.",
  },
  {
    categorySlug: "juice",
    nameEn: "Mixed Fruit Juice",
    nameBn: "মিক্সড ফ্রুট জুস",
    price: 120,
    image:
      "https://images.pexels.com/photos/33337322/pexels-photo-33337322.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    isBestseller: false,
    description: "Fresh seasonal fruits blended to perfection.",
  },
  {
    categorySlug: "juice",
    nameEn: "Orange Refresher",
    nameBn: "অরেজ রিফ্রেশার",
    price: 100,
    image:
      "https://images.pexels.com/photos/8228297/pexels-photo-8228297.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    isBestseller: true,
    description: "Chilled orange juice with a hint of mint.",
  },
  {
    categorySlug: "coffee",
    nameEn: "Cappuccino",
    nameBn: "ক্যাপুচিনো",
    price: 150,
    image:
      "https://images.pexels.com/photos/28496565/pexels-photo-28496565.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: true,
    description: "Rich espresso with steamed milk foam art.",
  },
  {
    categorySlug: "coffee",
    nameEn: "Cold Coffee",
    nameBn: "কোল্ড কফি",
    price: 140,
    image:
      "https://images.pexels.com/photos/15801080/pexels-photo-15801080.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    isBestseller: false,
    description: "Creamy blended cold coffee topped with whipped cream.",
  },
  {
    categorySlug: "set-menu",
    nameEn: "Family Feast",
    nameBn: "ফ্যামিলি ফিস্ট",
    price: 899,
    image:
      "https://images.pexels.com/photos/17294773/pexels-photo-17294773.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    isBestseller: true,
    description: "Burgers, fries, drinks and wings for 4 people.",
  },
  {
    categorySlug: "set-menu",
    nameEn: "Party Platter",
    nameBn: "পার্টি প্ল্যাটার",
    price: 1499,
    image:
      "https://images.pexels.com/photos/17001777/pexels-photo-17001777.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    isBestseller: false,
    description: "A grand spread perfect for celebrations.",
  },
];

async function seed() {
  console.log("Seeding categories...");
  await db.insert(categories).values(categoryData).onConflictDoNothing({ target: categories.slug });

  const allCategories = await db.select().from(categories);
  const catMap = new Map(allCategories.map((c) => [c.slug, c.id]));

  console.log("Seeding menu items...");
  for (const item of itemData) {
    const categoryId = catMap.get(item.categorySlug);
    if (!categoryId) continue;
    const existing = await db
      .select({ id: menuItems.id })
      .from(menuItems)
      .where(eq(menuItems.nameEn, item.nameEn))
      .limit(1);
    if (existing.length > 0) {
      console.log(`Skipping ${item.nameEn}`);
      continue;
    }
    await db.insert(menuItems).values({
      categoryId,
      nameEn: item.nameEn,
      nameBn: item.nameBn,
      price: item.price,
      image: item.image,
      isBestseller: item.isBestseller,
      description: item.description,
    });
  }

  console.log("Seed complete.");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
