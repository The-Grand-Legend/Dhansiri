import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

const secret = new TextEncoder().encode(process.env.JWT_SECRET || "fallback-secret");

export async function createAdminToken() {
  return new SignJWT({ role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("8h")
    .sign(secret);
}

export async function verifyAdminToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload.role === "admin";
  } catch {
    return false;
  }
}

export async function getAdminCookie() {
  const cookieStore = await cookies();
  return cookieStore.get("dhanshiri_admin")?.value;
}

export async function isAdminAuthenticated() {
  const token = await getAdminCookie();
  if (!token) return false;
  return verifyAdminToken(token);
}
